#!/bin/bash

mkdir kopia-home-22012021-1304
cd kopia-home-220112021-1304
mkdir zad2
cd zad2
mkdir s96418
cd s96418
echo "kopia-home-22012021-1304, zad2, s96418" >> log.txt